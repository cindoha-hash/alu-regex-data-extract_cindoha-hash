"""
ALU Regex Data Extraction & Secure Validation
=============================================
Author      : INDOHA (Junior Frontend Developer — Galaxy Logistics)
Assignment  : Data Extraction & Secure Validation
Language    : Python 3 (standard library only — no third-party deps)

WHAT THIS PROGRAM DOES
----------------------
Reads an untrusted, production-style text dump from ``input/raw-text.txt``
and extracts the following data types using ONLY regular expressions:

    1. Email addresses (general)
    2. ALU-specific emails:
         - @alueducation.com         (official)
         - @alumni.alueducation.com  (alumni)
         - @si.alueducation.com      (SI)
    3. Credit card numbers (Visa / MasterCard / AmEx / Discover / JCB)
       — additionally validated with the Luhn algorithm and MASKED in output
    4. URLs (http / https, optional port, path, query)
    5. Phone numbers (international, US, RW, KE, with separators)
    6. HTML tags
    7. Hashtags
    8. Currency amounts (USD, EUR, GBP, JPY, RWF, written as $/€/£/¥/RWF)
    9. Time in 12-hour and 24-hour notation

The validated, structured result is written to ``output/sample-output.json``.

SECURITY POSTURE (see SECURITY NOTES section near the bottom too)
-----------------------------------------------------------------
The input is treated as HOSTILE. Concretely we:
  * Cap the input size (no unbounded reads).
  * Strip ASCII control characters before matching (defangs many payloads).
  * Use anchored, non-greedy patterns and ``re.fullmatch`` for final
    validators — never ``eval`` / ``exec`` / shell on extracted data.
  * Reject credit cards that fail the Luhn checksum (e.g. 1234-5678-...).
  * MASK PANs and emails in the JSON output so logs / artifacts don't
    leak PII (e.g. ``j***e@alueducation.com``, ``************5454``).
  * Detect common injection markers (XSS, SQLi, javascript: URIs) and
    move suspicious snippets into a ``threats_detected`` bucket instead
    of the normal extracted results.
  * Disallow look-alike ALU domains such as
    ``user@alueducation.com.evil.com`` via strict fullmatch validators.

USAGE
-----
    python3 src/main.py
    # or
    python3 src/main.py path/to/other-input.txt path/to/other-output.json
"""

from __future__ import annotations

import json
import os
import re
import sys
from typing import Dict, List


# ---------------------------------------------------------------------------
# Configuration / hard limits  (defensive programming)
# ---------------------------------------------------------------------------

# Reject inputs larger than 1 MiB. Real CRM exports we'd page; for an
# assignment this prevents accidental DoS by huge or pathological files.
MAX_INPUT_BYTES = 1 * 1024 * 1024

# Default file locations (relative to project root, two levels up from this file)
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
DEFAULT_INPUT = os.path.join(PROJECT_ROOT, "input", "raw-text.txt")
DEFAULT_OUTPUT = os.path.join(PROJECT_ROOT, "output", "sample-output.json")


# ---------------------------------------------------------------------------
# REGEX PATTERNS
# ---------------------------------------------------------------------------
# Every pattern below is commented. Patterns used for *extraction* run over
# the whole text; patterns used for *final validation* are anchored and used
# with re.fullmatch() so they accept only the exact, well-formed token.
# ---------------------------------------------------------------------------

# --- Emails ----------------------------------------------------------------
# Local part: letters, digits, and the safe specials . _ % + -
# Domain    : one or more labels separated by dots, then a TLD of >=2 letters.
# Word boundaries via lookarounds prevent grabbing "user@@evil..com" etc.
EMAIL_EXTRACT = re.compile(
    r"""(?ix)                       # case-insensitive, verbose
    (?<![A-Z0-9._%+\-@])            # left boundary: not part of a bigger token
    (
        [A-Z0-9._%+\-]+             # local-part
        @
        (?:[A-Z0-9](?:[A-Z0-9\-]{0,61}[A-Z0-9])?\.)+   # one or more labels
        [A-Z]{2,24}                                    # TLD
    )
    (?![A-Z0-9._%+\-@])             # right boundary
    """
)

# Strict validator (used with fullmatch) — rejects @@, .., leading/trailing dots
EMAIL_STRICT = re.compile(
    r"""(?ix)
    ^[A-Z0-9._%+\-]+                # local-part (no consecutive specials checked below)
    @
    (?:[A-Z0-9](?:[A-Z0-9\-]{0,61}[A-Z0-9])?\.)+
    [A-Z]{2,24}$
    """
)

# ALU-specific validators — anchored, exact domains only.
# These prevent spoofed look-alikes like "user@alueducation.com.evil.com".
ALU_OFFICIAL = re.compile(r"(?i)^[A-Z0-9._%+\-]+@alueducation\.com$")
ALU_ALUMNI   = re.compile(r"(?i)^[A-Z0-9._%+\-]+@alumni\.alueducation\.com$")
ALU_SI       = re.compile(r"(?i)^[A-Z0-9._%+\-]+@si\.alueducation\.com$")


# --- Credit card numbers ---------------------------------------------------
# Real-world PANs are 13-19 digits and often written with spaces or dashes
# every 4 digits (e.g. "5454 5454 5454 5454" or "4111-4111-4111-4111").
# AmEx is 15 digits and grouped 4-6-5 (e.g. "3782 822463 10005").
#
# We extract liberally, then validate with the Luhn algorithm.
CREDIT_CARD_EXTRACT = re.compile(
    r"""
    (?<!\d)                         # not preceded by another digit
    (
        (?:\d[ \-]?){12,18}\d       # 13-19 digits with optional space/dash separators
    )
    (?!\d)                          # not followed by another digit
    """,
    re.VERBOSE,
)


# --- URLs ------------------------------------------------------------------
# http or https, optional userinfo dropped, host, optional :port, optional
# path/query/fragment. We deliberately stop at whitespace and at characters
# that commonly close a URL in prose ("<", ">", quotes).
URL_EXTRACT = re.compile(
    r"""(?ix)
    \bhttps?://                                 # scheme
    (?:[A-Z0-9\-]+\.)+[A-Z]{2,24}               # host
    (?::\d{2,5})?                               # optional port
    (?:/[^\s<>"']*)?                            # optional path/query/fragment
    """
)


# --- Phone numbers ---------------------------------------------------------
# Accepts (in this order of alternatives):
#   +250 788 123 456
#   +254-20-555-0199
#   +1 (415) 555-0132
#   (415) 555-0199
#   415-555-0199
# Rejects vanity strings like 555-CALL-NOW (we require digits) and also
# refuses to "swallow" the middle of a longer digit run (the trailing
# lookahead rejects "5454 5454 5454" which is a partial card).
PHONE_EXTRACT = re.compile(
    r"""
    (?<!\d)
    (
        \+\d{1,3}[ \-.]?              # international: must start with +CC
        (?:\(\d{1,4}\)[ \-.]?)?
        \d{2,4}[ \-.]?
        \d{2,4}[ \-.]?
        \d{2,4}
      |
        \(\d{2,4}\)[ \-.]?            # US with parenthesized area code
        \d{3}[ \-.]?\d{4}
      |
        \d{3}[ \-.]\d{3}[ \-.]\d{4}   # plain US: 415-555-0199
    )
    (?![ \-.]?\d)                     # not part of a longer digit run / card
    """,
    re.VERBOSE,
)

# Obvious date shape, used to drop phone false-positives like "2026-03-15".
DATE_SHAPE = re.compile(r"^\s*(?:\d{1,2}[-/.]\d{1,2}[-/.]\d{2,4}|\d{4}[-/.]\d{1,2}[-/.]\d{1,2})\s*$")


# --- HTML tags -------------------------------------------------------------
# Matches opening, closing, and self-closing tags such as <div class="x">,
# </span>, <br/>. Attributes are allowed but not deeply parsed.
HTML_TAG_EXTRACT = re.compile(
    r"""</?              # opening or closing slash
        [A-Za-z][A-Za-z0-9]*   # tag name
        (?:\s+[^<>]*?)?  # optional attributes (no nested < or >)
        /?>              # optional self-close, then >
    """,
    re.VERBOSE,
)


# --- Hashtags --------------------------------------------------------------
# A # followed by at least one letter and 0+ letters/digits/underscores.
# This intentionally REJECTS purely numeric tags like "#1".
HASHTAG_EXTRACT = re.compile(r"(?<![A-Za-z0-9_])#([A-Za-z][A-Za-z0-9_]*)")


# --- Currency amounts ------------------------------------------------------
# Supports common currency symbols and the ISO codes used in our region.
# Examples matched: $1,249.99 — €3,890.75 — £120 — ¥45000 —
# USD 4,250.00 — RWF 5,400,000
# Amount component: prefer a grouped number with comma separators
# (e.g. 1,249.99 — 24,800,000) but fall back to a plain integer/decimal
# (e.g. 45000 — 120). The grouped alternative REQUIRES at least one comma
# so a plain "45000" isn't truncated to "450".
_AMOUNT = r"(?:\d{1,3}(?:,\d{3})+(?:\.\d{1,2})?|\d+(?:\.\d{1,2})?)"
CURRENCY_EXTRACT = re.compile(
    rf"""
    (?:
        (?P<sym>[$€£¥])\s?(?P<amt1>{_AMOUNT})
      |
        (?P<code>USD|EUR|GBP|JPY|RWF)\s+(?P<amt2>{_AMOUNT})
    )
    """,
    re.VERBOSE,
)


# --- Time (12-hour and 24-hour) -------------------------------------------
# 24-hour: 00:00 — 23:59 (optional :SS). The lookbehind (?<![+\-\d])
# refuses matches like "+02:00" or "-05:30" which are timezone offsets,
# not times of day.
# 12-hour: 1:00 AM/PM — 12:59 AM/PM (optional :SS, case-insensitive).
TIME_24H = re.compile(r"(?<![+\-\d])([01]\d|2[0-3]):([0-5]\d)(?::([0-5]\d))?(?!\d)")
TIME_12H = re.compile(r"(?<!\d)(1[0-2]|0?[1-9]):([0-5]\d)(?::([0-5]\d))?\s?([AaPp][Mm])\b")


# --- Injection / hostile-content markers ----------------------------------
# We do NOT try to be a full XSS/SQLi engine. We just flag obvious markers so
# downstream renderers / SQL layers can refuse to process them. Each
# alternative below is designed to swallow the WHOLE payload (e.g. the
# entire <img ... onerror="..."> tag) so that when we later redact threat
# spans, no part of an attack leaks back into the "clean" extractions.
THREAT_MARKERS = re.compile(
    r"""(?ix)
      <\s*script\b[^>]*>            # <script ...> opening tag
    | <\s*/\s*script\s*>            # </script>
    | javascript\s*:[^\s"'<>]*      # javascript: URI (consume the rest)
    | <\s*img\b[^>]*\bonerror\b[^>]*> # <img ... onerror=...> full tag
    | on\w+\s*=\s*(?:"[^"]*"|'[^']*')  # inline event handlers
    | \bdrop\s+table\b[^;]*;?        # SQL: DROP TABLE ...;
    | \bunion\s+select\b             # SQL: UNION SELECT
    | (?:^|\s)'\s*or\s*1\s*=\s*1[^\n]* # SQL: ' OR 1=1 ...
    """
)


def redact_threats(text: str) -> str:
    """Replace every threat-marker span with spaces of equal length.

    Preserving lengths keeps line/column positions stable for any later
    diagnostics, while ensuring URLs, cards, phones etc. that live INSIDE
    a malicious payload cannot leak into the clean output. This is the
    "defense in depth" companion to the threats_detected bucket.
    """
    return THREAT_MARKERS.sub(lambda m: " " * len(m.group(0)), text)


# ---------------------------------------------------------------------------
# HELPERS — sanitization, Luhn, masking
# ---------------------------------------------------------------------------

def sanitize(text: str) -> str:
    """Strip ASCII control characters (except \t \n \r) before regex work.

    Many payloads hide separators with NUL/BEL/etc. Removing them up-front
    means the regex sees the same string a human reader would.
    """
    return re.sub(r"[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]", "", text)


def luhn_valid(digits: str) -> bool:
    """Return True if the given digit string passes the Luhn checksum.

    The Luhn algorithm is the industry standard for detecting accidental
    errors in credit-card-like identifiers (NOT a security check on its
    own, but enough to reject obvious fakes like 1234-5678-9012-3456).
    """
    digits = re.sub(r"\D", "", digits)
    if not (13 <= len(digits) <= 19):
        return False
    total = 0
    # Walk from the right; double every second digit.
    for i, ch in enumerate(reversed(digits)):
        n = ord(ch) - 48
        if i % 2 == 1:
            n *= 2
            if n > 9:
                n -= 9
        total += n
    return total % 10 == 0


def detect_card_brand(digits: str) -> str:
    """Best-effort brand detection from the IIN/BIN prefix and length."""
    d = re.sub(r"\D", "", digits)
    n = len(d)
    if n == 15 and (d.startswith("34") or d.startswith("37")):
        return "AmEx"
    if 13 <= n <= 19 and d.startswith("4"):
        return "Visa"
    if n == 16 and (
        d[:2] in {"51", "52", "53", "54", "55"}
        or 2221 <= int(d[:4]) <= 2720
    ):
        return "MasterCard"
    if n == 16 and (d.startswith("6011") or d.startswith("65") or d[:3] in {"644", "645", "646", "647", "648", "649"}):
        return "Discover"
    if n in (16, 19) and d.startswith("35"):
        return "JCB"
    return "Unknown"


def mask_card(digits: str) -> str:
    """Mask a PAN, leaving only the last 4 digits visible (PCI-DSS style)."""
    d = re.sub(r"\D", "", digits)
    return ("*" * (len(d) - 4)) + d[-4:]


def mask_email(addr: str) -> str:
    """Mask an email's local part so logs don't leak full PII.

    ``jeanette.mukamana@alueducation.com`` -> ``j***a@alueducation.com``
    """
    try:
        local, domain = addr.split("@", 1)
    except ValueError:
        return "***"
    if len(local) <= 2:
        masked_local = local[0] + "*"
    else:
        masked_local = f"{local[0]}***{local[-1]}"
    return f"{masked_local}@{domain}"


# ---------------------------------------------------------------------------
# CORE EXTRACTION — returns a structured dict
# ---------------------------------------------------------------------------

def extract_all(text: str) -> Dict[str, object]:
    """Run every extractor on ``text`` and return a JSON-ready dict.

    The dict separates legitimate findings from threats so a downstream
    system can render the safe parts and quarantine the rest.

    DEFENSE-IN-DEPTH ORDER:
      1. Scan the ORIGINAL text for threat markers -> threats_detected.
      2. Build a "safe_text" with every threat span blanked out.
      3. Run every other extractor against safe_text, so URLs / cards /
         phones / emails that lived INSIDE a malicious payload cannot
         leak into the clean output.
    """
    findings: Dict[str, object] = {
        "emails": {
            "all":             [],   # every valid email found (masked)
            "alu_official":    [],   # @alueducation.com
            "alu_alumni":      [],   # @alumni.alueducation.com
            "alu_si":          [],   # @si.alueducation.com
            "rejected":        [],   # malformed strings that LOOKED like emails
        },
        "credit_cards":    [],       # only Luhn-valid, masked
        "urls":            [],
        "phone_numbers":   [],
        "html_tags":       [],
        "hashtags":        [],
        "currency_amounts":[],
        "times":           {"12h": [], "24h": []},
        "threats_detected":[],
    }

    # ----- 1) Threat sweep on ORIGINAL text -------------------------------
    seen_threats: set = set()
    for m in THREAT_MARKERS.finditer(text):
        snippet = m.group(0).strip()
        if len(snippet) > 200:
            snippet = snippet[:200] + "...[truncated]"
        key = snippet.lower()
        if key in seen_threats:
            continue
        seen_threats.add(key)
        findings["threats_detected"].append({"type": "pattern_match", "snippet": snippet})

    # ----- 2) Redact threats; everything below runs on safe_text ----------
    safe_text = redact_threats(text)

    # ----- Emails ----------------------------------------------------------
    seen_emails: set = set()
    for raw in EMAIL_EXTRACT.findall(safe_text):
        candidate = raw.strip(".,;:<>()[]{}\"'")
        if not EMAIL_STRICT.fullmatch(candidate):
            findings["emails"]["rejected"].append(candidate)
            continue
        if candidate.lower() in seen_emails:
            continue
        seen_emails.add(candidate.lower())

        masked = mask_email(candidate)
        findings["emails"]["all"].append(masked)
        if ALU_OFFICIAL.fullmatch(candidate):
            findings["emails"]["alu_official"].append(masked)
        elif ALU_ALUMNI.fullmatch(candidate):
            findings["emails"]["alu_alumni"].append(masked)
        elif ALU_SI.fullmatch(candidate):
            findings["emails"]["alu_si"].append(masked)

    # Surface spoofed look-alikes such as "user@alueducation.com.evil.com".
    for spoof in re.findall(r"[A-Za-z0-9._%+\-]+@alueducation\.com\.[A-Za-z.\-]+", safe_text):
        if spoof not in findings["emails"]["rejected"]:
            findings["emails"]["rejected"].append(spoof)

    # ----- Credit cards ----------------------------------------------------
    seen_cards: set = set()
    valid_card_digits: set = set()
    for raw in CREDIT_CARD_EXTRACT.findall(safe_text):
        digits = re.sub(r"\D", "", raw)
        if digits in seen_cards:
            continue
        seen_cards.add(digits)
        if not luhn_valid(digits):
            # silently drop — fake "1234-5678-9012-3456" lands here
            continue
        valid_card_digits.add(digits)
        findings["credit_cards"].append({
            "brand":  detect_card_brand(digits),
            "masked": mask_card(digits),
            "length": len(digits),
        })

    # ----- URLs ------------------------------------------------------------
    for raw in URL_EXTRACT.findall(safe_text):
        url = raw.rstrip(").,;:>\"'")
        # Belt-and-braces: refuse any URL containing < or javascript:
        if "<" in url or url.lower().startswith("javascript:"):
            continue
        if url not in findings["urls"]:
            findings["urls"].append(url)

    # ----- Phone numbers ---------------------------------------------------
    for raw in PHONE_EXTRACT.findall(safe_text):
        normalized = raw.strip()
        # Drop obvious dates (e.g. "2026-03-15", "14-03-2026").
        if DATE_SHAPE.match(normalized):
            continue
        digits_only = re.sub(r"\D", "", normalized)
        # E.164 range — at least 8 to filter "555-0199" type extensions,
        # at most 15 per the standard.
        if not (8 <= len(digits_only) <= 15):
            continue
        # If the digit run is a substring of a recognized credit-card PAN,
        # this is almost certainly a card fragment, not a phone.
        if any(digits_only in cd for cd in valid_card_digits):
            continue
        if normalized not in findings["phone_numbers"]:
            findings["phone_numbers"].append(normalized)

    # ----- HTML tags -------------------------------------------------------
    for tag in HTML_TAG_EXTRACT.findall(safe_text):
        if THREAT_MARKERS.search(tag):
            findings["threats_detected"].append({"type": "html_injection", "snippet": tag})
            continue
        if tag not in findings["html_tags"]:
            findings["html_tags"].append(tag)

    # ----- Hashtags --------------------------------------------------------
    for tag in HASHTAG_EXTRACT.findall(safe_text):
        full = f"#{tag}"
        if full not in findings["hashtags"]:
            findings["hashtags"].append(full)

    # ----- Currency --------------------------------------------------------
    for m in CURRENCY_EXTRACT.finditer(safe_text):
        sym  = m.group("sym")  or ""
        code = m.group("code") or ""
        amt  = m.group("amt1") or m.group("amt2") or ""
        unit = sym or code
        findings["currency_amounts"].append({
            "currency": unit,
            "amount":   amt,
            "raw":      m.group(0).strip(),
        })

    # ----- Times -----------------------------------------------------------
    for m in TIME_24H.finditer(safe_text):
        # Skip 24h matches that are immediately followed by AM/PM — those
        # are actually 12-hour values caught by the next loop.
        end = m.end()
        tail = safe_text[end:end + 4]
        if re.match(r"\s?[AaPp][Mm]\b", tail):
            continue
        findings["times"]["24h"].append(m.group(0))
    for m in TIME_12H.finditer(safe_text):
        findings["times"]["12h"].append(m.group(0))

    return findings


# ---------------------------------------------------------------------------
# I/O + CLI
# ---------------------------------------------------------------------------

def load_input(path: str) -> str:
    """Read input safely: bounded size, UTF-8, sanitized."""
    size = os.path.getsize(path)
    if size > MAX_INPUT_BYTES:
        raise SystemExit(
            f"[refused] input file {path} is {size} bytes, "
            f"larger than the {MAX_INPUT_BYTES}-byte safety cap."
        )
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        return sanitize(fh.read())


def write_output(path: str, data: Dict[str, object]) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2, ensure_ascii=False)


def print_summary(findings: Dict[str, object]) -> None:
    """Pretty console summary — masked, so safe to paste into chat / logs."""
    e = findings["emails"]
    print("=" * 60)
    print("  ALU REGEX DATA EXTRACTION — SUMMARY")
    print("=" * 60)
    print(f"  Emails (valid)          : {len(e['all'])}")
    print(f"    - ALU official        : {len(e['alu_official'])}")
    print(f"    - ALU alumni          : {len(e['alu_alumni'])}")
    print(f"    - ALU SI              : {len(e['alu_si'])}")
    print(f"  Emails (rejected)       : {len(e['rejected'])}")
    print(f"  Credit cards (Luhn ok)  : {len(findings['credit_cards'])}")
    print(f"  URLs                    : {len(findings['urls'])}")
    print(f"  Phone numbers           : {len(findings['phone_numbers'])}")
    print(f"  HTML tags               : {len(findings['html_tags'])}")
    print(f"  Hashtags                : {len(findings['hashtags'])}")
    print(f"  Currency amounts        : {len(findings['currency_amounts'])}")
    print(f"  Times (24h / 12h)       : "
          f"{len(findings['times']['24h'])} / {len(findings['times']['12h'])}")
    print(f"  Threats quarantined     : {len(findings['threats_detected'])}")
    print("=" * 60)


def main(argv: List[str]) -> int:
    in_path  = argv[1] if len(argv) > 1 else DEFAULT_INPUT
    out_path = argv[2] if len(argv) > 2 else DEFAULT_OUTPUT

    text     = load_input(in_path)
    findings = extract_all(text)
    write_output(out_path, findings)
    print_summary(findings)
    print(f"  Full JSON written to: {out_path}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))


# ===========================================================================
# SECURITY NOTES (also referenced in README.md)
# ===========================================================================
# 1. Input is read with a hard size cap (MAX_INPUT_BYTES) and decoded with
#    errors="replace" to avoid crashing on bad bytes.
# 2. Control characters are stripped BEFORE pattern matching so attackers
#    can't smuggle separators or break our extractors with NUL/BEL/etc.
# 3. We never call eval/exec/shell on any extracted value. Everything that
#    leaves this program goes through json.dump, which auto-escapes.
# 4. Emails use a strict re.fullmatch validator and an exact-domain check
#    for the three ALU variants, so "user@alueducation.com.evil.com" is
#    correctly REJECTED as a spoof.
# 5. Credit card numbers are validated with the Luhn checksum and MASKED
#    (last 4 digits only) before they ever appear in JSON, console, or
#    logs. This mirrors PCI-DSS guidance.
# 6. URLs containing "<" or starting with "javascript:" are dropped so we
#    can't help propagate a stored-XSS or open-redirect payload.
# 7. HTML fragments that contain script/onerror/etc. are routed to
#    `threats_detected` instead of `html_tags` so a downstream renderer
#    can refuse to display them.
# 8. SQL-injection markers (DROP TABLE, ' OR 1=1, UNION SELECT) are
#    flagged into `threats_detected` and never echoed unmodified.
# 9. Emails in console output are masked (j***e@domain) so terminal
#    history doesn't become an accidental PII dump.
# ===========================================================================
